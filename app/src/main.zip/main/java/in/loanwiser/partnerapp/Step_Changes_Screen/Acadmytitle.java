package in.loanwiser.partnerapp.Step_Changes_Screen;

public class Acadmytitle {

    private String name;
    private boolean expanded;


    public Acadmytitle(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

}
