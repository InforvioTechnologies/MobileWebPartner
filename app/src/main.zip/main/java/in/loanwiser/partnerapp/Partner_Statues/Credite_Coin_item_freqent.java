package in.loanwiser.partnerapp.Partner_Statues;

public class Credite_Coin_item_freqent {

    private String head_line;
    private String icon;

    public String gethead_line() {
        return head_line;
    }

    public void sethead_line(String head_line) {
        this.head_line = head_line;
    }

    public String geticon() {
        return icon;
    }

    public void seticon(String icon) {
        this.icon = icon;
    }

    public Credite_Coin_item_freqent(String head_line, String icon) {

        this.head_line = head_line;

        this.icon = icon;

    }

}
