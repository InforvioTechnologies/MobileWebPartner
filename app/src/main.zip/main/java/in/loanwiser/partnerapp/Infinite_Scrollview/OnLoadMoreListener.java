package in.loanwiser.partnerapp.Infinite_Scrollview;

/**
 * Created by S.Shahini on 8/8/16.
 * callback for notify view when user reached to list ends.
 */
public interface OnLoadMoreListener {
    void onLoadMore();
}
