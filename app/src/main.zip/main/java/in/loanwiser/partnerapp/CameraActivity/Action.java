package in.loanwiser.partnerapp.CameraActivity;

public class Action {

	public static final String ACTION_PICK = "luminous.ACTION_PICK";
	public static final String ACTION_MULTIPLE_PICK = "luminous.ACTION_MULTIPLE_PICK";
}
