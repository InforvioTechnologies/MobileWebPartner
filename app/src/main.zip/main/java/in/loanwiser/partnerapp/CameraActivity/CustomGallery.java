package in.loanwiser.partnerapp.CameraActivity;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;

}
