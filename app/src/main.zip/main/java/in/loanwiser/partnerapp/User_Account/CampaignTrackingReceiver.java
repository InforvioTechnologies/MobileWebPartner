package in.loanwiser.partnerapp.User_Account;

import android.content.Context;
import android.content.Intent;

class CampaignTrackingReceiver {
    public void onReceive(Context applicationContext, Intent intent) {

    }
}
