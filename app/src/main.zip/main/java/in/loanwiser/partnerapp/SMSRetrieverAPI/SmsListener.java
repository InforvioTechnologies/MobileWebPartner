package in.loanwiser.partnerapp.SMSRetrieverAPI;

public interface SmsListener {
    public void messageReceived(String messageText);
}
