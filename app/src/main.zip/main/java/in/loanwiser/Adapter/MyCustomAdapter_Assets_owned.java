package in.loanwiser.Adapter;

public class MyCustomAdapter_Assets_owned {
}
