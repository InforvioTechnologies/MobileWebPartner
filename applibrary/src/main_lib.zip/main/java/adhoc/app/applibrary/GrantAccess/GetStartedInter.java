package adhoc.app.applibrary.GrantAccess;

import org.json.JSONArray;

/**
 * Created by user on 9/8/2016.
 */
public interface GetStartedInter {
    public void onGetSaratedCompleted(String res);
    public void onGrantAccessCompleted(String res);
}
